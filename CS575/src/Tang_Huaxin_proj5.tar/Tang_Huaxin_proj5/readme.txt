To run this code:
javac createkn01.java
java createkn01 -k knapsack01.txt

javac bruteforce.java
java bruteforce -k knapsack01.txt

javac dynpro.java
java dynpro -k knapsack01.txt

javac backtrack.java
java backtrack -k knapsack01.txt
